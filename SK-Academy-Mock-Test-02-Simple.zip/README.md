# SK Academy Simple Mock Test 02

Standalone browser app. No Node.js, database, Firebase, Supabase, or Replit AI required.

Open `index.html` in a browser or publish the folder with GitHub Pages.

Features:
- 100 MCQs
- 60-minute countdown
- Previous/Next navigation
- Answer tracking and progress bar
- Automatic submission when time ends
- Automatic score, percentage, correct/wrong/unanswered
- Review answers
- Mobile responsive
- Student name and last result stored locally in the browser

This version is designed for fast Mock Test 02 delivery. It is a client-side test and does not provide a central admin database or secure server-side exam control.
